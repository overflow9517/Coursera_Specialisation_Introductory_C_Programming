#include <stdio.h>
#include <stdlib.h>

size_t maxSeq(int *array, size_t n) {
    if (n == 0) {
        return 0;
    }

    size_t maxSeq = 1;
    size_t currentSeq = 1;

    for (size_t i = 1; i < n; i++) {
        if (array[i] > array[i - 1]) {
            currentSeq++;
        } else {
            if (currentSeq > maxSeq) {
                maxSeq = currentSeq;
            }
            currentSeq = 1;
        }
    }   

    if (currentSeq > maxSeq) {
        maxSeq = currentSeq;
    }
    
    return maxSeq;

}

