#include <stdio.h>
#include <stdlib.h>



struct _retire_info
{
    int months;
    double contribution;
    double rate_of_return;
};

typedef struct _retire_info retire_info;


void retirement(int startAge, double initial, retire_info working, retire_info retired)
{
    //compute the retirement account balance each month
    double balance = initial;
    for (int i = 0; i < working.months; i++)
    {
        printf("Age %3d month %2d you have $%.2f\n", startAge / 12, startAge % 12, balance);
        balance += balance * working.rate_of_return + working.contribution;
        startAge++;
    }

    //compute the retirement account balance each month of retirment
    for (int i = 0; i < retired.months; i++)
    {
        printf("Age %3d month %2d you have $%.2f\n", startAge / 12, startAge % 12, balance);
        balance += balance * retired.rate_of_return + retired.contribution;
        startAge++;
    }
}





int main() {
    int startAge = 327; // 27 years and 3 months
    double initial = 21345.0;

    retire_info working;
    working.months = 489; // 40 years and 9 months
    working.contribution = 1000.0;
    working.rate_of_return = 0.045 / 12;

    retire_info retired;
    retired.months = 384; // 32 years
    retired.contribution = -4000.0;
    retired.rate_of_return = 0.01 / 12;

    retirement(startAge, initial, working, retired);
    return EXIT_SUCCESS;
}