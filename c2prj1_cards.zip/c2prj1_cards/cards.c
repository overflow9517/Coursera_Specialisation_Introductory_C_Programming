#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include "cards.h"


void assert_card_valid(card_t c) {
  assert(c.value >= 2 && c.value <= VALUE_ACE);
  assert(c.suit >= SPADES && c.suit < NUM_SUITS); 
}


const char * ranking_to_string(hand_ranking_t r) {
  static const char *rankings[] = {
    "STRAIGHT_FLUSH",
    "FOUR_OF_A_KIND",
    "FULL_HOUSE",
    "FLUSH",
    "STRAIGHT",
    "THREE_OF_A_KIND",
    "TWO_PAIR",
    "PAIR",
    "NOTHING"
  };
  if (r >= STRAIGHT_FLUSH && r <= NOTHING) {
    return rankings[r];
  } else {
    return "Invalid hand_ranking_t";
  }
}


char value_letter(card_t c) {
  if (c.value >= 2 && c.value <= 9) {
    return '0' + c.value;
  }
  if (c.value == 10) {
    return '0';
  }
  if (c.value == VALUE_JACK) {
    return 'J';
  }
  if (c.value == VALUE_QUEEN) {
    return 'Q';
  }
  if (c.value == VALUE_KING) {
    return 'K';
  }
  if (c.value == VALUE_ACE) {
    return 'A';
  }
  return 'x';
}


char suit_letter(card_t c) {
  if (c.suit == SPADES) {
    return 's';
  }
  if (c.suit == HEARTS) {
    return 'h';
  }
  if (c.suit == DIAMONDS) {
    return 'd';
  }
  if (c.suit == CLUBS) {
    return 'c';
  }
  return 'x';
}


void print_card(card_t c) {
  printf("%c%c", value_letter(c), suit_letter(c));
}


card_t card_from_letters(char value_let, char suit_let) {
  card_t temp;

  switch (value_let) {
    case '2': temp.value = 2; break;
    case '3': temp.value = 3; break;
    case '4': temp.value = 4; break;
    case '5': temp.value = 5; break;
    case '6': temp.value = 6; break;
    case '7': temp.value = 7; break;
    case '8': temp.value = 8; break;
    case '9': temp.value = 9; break;
    case '0': temp.value = 10; break;
    case 'J': temp.value = VALUE_JACK; break;
    case 'Q': temp.value = VALUE_QUEEN; break;
    case 'K': temp.value = VALUE_KING; break;
    case 'A': temp.value = VALUE_ACE; break;
    default: 
      fprintf(stderr, "Invalid card value: %c\n", value_let);
      exit(EXIT_FAILURE);
  }

  switch (suit_let) {
    case 's': temp.suit = SPADES; break;
    case 'h': temp.suit = HEARTS; break;
    case 'd': temp.suit = DIAMONDS; break;
    case 'c': temp.suit = CLUBS; break;
    default: 
      fprintf(stderr, "Invalid card suit: %c\n", suit_let);
      exit(EXIT_FAILURE);
  }

  return temp;
}


  card_t card_from_num(unsigned c) {
    assert(c < 52); 
    
    card_t temp;
    temp.value = (c % 13) + 2; 
    temp.suit = c / 13; 
    return temp;
  }
